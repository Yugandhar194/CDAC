﻿using System;
using LibraryManagement;

namespace LibraryManagementApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Library library = new Library();

            // Prepopulate the library with some books
            library.AddBook(new Book("The Great Gatsby", "F. Scott Fitzgerald"));
            library.AddBook(new Book("1984", "George Orwell"));
            library.AddBook(new Book("To Kill a Mockingbird", "Harper Lee"));
            library.AddBook(new Book("The Great Rohit Sharma", "Rahul Bharaskar"));

            int choice;
            do
            {
                Console.WriteLine("\nLibrary Management System");
                Console.WriteLine("1. List all books");
                Console.WriteLine("2. Borrow a book");
                Console.WriteLine("3. Return a book");
                Console.WriteLine("4. Exit");
                Console.Write("Enter your choice: ");
                if (!int.TryParse(Console.ReadLine(), out choice))
                {
                    Console.WriteLine("Invalid input! Please enter a number between 1 and 4.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        ListAllBooks(library);
                        break;
                    case 2:
                        BorrowBook(library);
                        break;
                    case 3:
                        ReturnBook(library);
                        break;
                    case 4:
                        Console.WriteLine("Exiting... Thank you!");
                        break;
                    default:
                        Console.WriteLine("Invalid choice! Please try again.");
                        break;
                }
            } while (choice != 4);
        }

        private static void ListAllBooks(Library library)
        {
            Console.WriteLine("\nBooks in the library:");
            library.ListAllBooks();
        }

        private static void BorrowBook(Library library)
        {
            Console.WriteLine("\nEnter the title of the book you want to borrow:");
            string title = Console.ReadLine();

            // Find the book in the library
            Book? book = library.GetBookByTitle(title);
            if (book != null)
            {
                book.BorrowBook();
            }
            else
            {
                Console.WriteLine("Book not found in the library.");
            }
        }

        private static void ReturnBook(Library library)
        {
            Console.WriteLine("\nEnter the title of the book you want to return:");
            string title = Console.ReadLine();

            // Find the book in the library
            Book? book = library.GetBookByTitle(title);
            if (book != null)
            {
                book.ReturnBook();
            }
            else
            {
                Console.WriteLine("Book not found in the library.");
            }
        }
    }
}
