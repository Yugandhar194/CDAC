﻿using System;
using System.IO;

namespace FileOperation
{
    public class FileManager
    {
        public void MoveFiles(string sourcePath, string destinationPath, string fileExtension)
        {
            if (File.Exists(sourcePath))
            {
                // Check if the file matches the extension
                if (Path.GetExtension(sourcePath).Equals(fileExtension, StringComparison.OrdinalIgnoreCase))
                {
                    string fileName = Path.GetFileName(sourcePath);
                    string destinationFile = Path.Combine(destinationPath, fileName);

                    // Ensure the destination directory exists
                    if (!Directory.Exists(destinationPath))
                    {
                        Directory.CreateDirectory(destinationPath);
                    }

                    File.Move(sourcePath, destinationFile);
                    Console.WriteLine($"File '{fileName}' moved successfully.");
                }
                else
                {
                    Console.WriteLine($"File extension mismatch. Expected {fileExtension}, found {Path.GetExtension(sourcePath)}.");
                }
            }
            else if (Directory.Exists(sourcePath))
            {
                string[] files = Directory.GetFiles(sourcePath, $"*{fileExtension}");

                if (files.Length == 0)
                {
                    Console.WriteLine("No files found with the specified extension.");
                    return;
                }

                if (!Directory.Exists(destinationPath))
                {
                    Directory.CreateDirectory(destinationPath);
                }

                foreach (var file in files)
                {
                    string fileName = Path.GetFileName(file);
                    string destinationFile = Path.Combine(destinationPath, fileName);

                    File.Move(file, destinationFile);
                    Console.WriteLine($"File '{fileName}' moved successfully.");
                }
            }
            else
            {
                Console.WriteLine("Source path does not exist.");
            }
        }
    }
}
