﻿using System;
using FileOperation;

FileManager fileManager = new FileManager();

while (true)
{
    Console.WriteLine("\nFile Cleanup Utility");
    Console.WriteLine("1. Move Files");
    Console.WriteLine("2. Exit");
    Console.Write("Enter your choice: ");
    string choice = Console.ReadLine();

    if (choice == "1")
    {
        Console.Write("Enter the source directory or file path: ");
        string sourcePath = Console.ReadLine();

        Console.Write("Enter the destination directory: ");
        string destinationPath = Console.ReadLine();

        Console.Write("Enter the file extension to move (e.g., .txt): ");
        string fileExtension = Console.ReadLine();

        fileManager.MoveFiles(sourcePath, destinationPath, fileExtension);
    }
    else if (choice == "2")
    {
        break;
    }
    else
    {
        Console.WriteLine("Invalid choice. Please enter 1 or 2.");
    }
}
