﻿namespace ExpenseTrackerLibrary
{
    public class Expense
    {
        public string Name { get; set; }
        public decimal Amount { get; set; }
        public string Category { get; set; }
        public DateTime Date { get; set; }

        public Expense(string name, decimal amount, string category, DateTime date)
        {
            Name = name;
            Amount = amount;
            Category = category;
            Date = date;
        }
    }
}
