﻿using System;
using ExpenseTrackerLibrary;
using System.Linq;
using ExpenseTrackerLibrary;  

class Program
{
    static void Main(string[] args)
    {
        var expenseManager = new ExpenseManager();
        bool isRunning = true;

        while (isRunning)
        {
            Console.Clear();
            Console.WriteLine("Personal Expense Tracker");
            Console.WriteLine("1. Add a new expense");
            Console.WriteLine("2. List all expenses");
            Console.WriteLine("3. Calculate total expenses");
            Console.WriteLine("4. Filter expenses by category");
            Console.WriteLine("5. Exit");
            Console.Write("Select an option: ");

            string input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    AddExpense(expenseManager);
                    break;
                case "2":
                    ListAllExpenses(expenseManager);
                    break;
                case "3":
                    CalculateTotalExpenses(expenseManager);
                    break;
                case "4":
                    FilterExpensesByCategory(expenseManager);
                    break;
                case "5":
                    isRunning = false;
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }

            if (isRunning)
            {
                Console.WriteLine("\nPress Enter to continue...");
                Console.ReadLine();
            }
        }
    }

    // Add a new expense
    static void AddExpense(ExpenseManager expenseManager)
    {
        Console.Clear();
        Console.WriteLine("Add a new expense");
        
        Console.Write("Enter expense name: ");
        string name = Console.ReadLine();

        Console.Write("Enter expense amount: ");
        decimal amount = decimal.Parse(Console.ReadLine());

        Console.Write("Enter expense category: ");
        string category = Console.ReadLine();

        Console.Write("Enter expense date (yyyy-mm-dd): ");
        DateTime date = DateTime.Parse(Console.ReadLine());

        expenseManager.AddExpense(name, amount, category, date);
        Console.WriteLine("Expense added successfully!");
    }

    // List all expenses
    static void ListAllExpenses(ExpenseManager expenseManager)
    {
        Console.Clear();
        Console.WriteLine("All Expenses:");

        var expenses = expenseManager.ListAllExpenses();
        if (expenses.Any())
        {
            foreach (var expense in expenses)
            {
                Console.WriteLine($"{expense.Date.ToShortDateString()} | {expense.Name} | {expense.Amount:C} | {expense.Category}");
            }
        }
        else
        {
            Console.WriteLine("No expenses recorded.");
        }
    }

    // Calculate total expenses
    static void CalculateTotalExpenses(ExpenseManager expenseManager)
    {
        Console.Clear();
        decimal total = expenseManager.GetTotalExpenses();
        Console.WriteLine($"Total expenses: {total:C}");
    }

    // Filter expenses by category
    static void FilterExpensesByCategory(ExpenseManager expenseManager)
    {
        Console.Clear();
        Console.Write("Enter category to filter by: ");
        string category = Console.ReadLine();

        var filteredExpenses = expenseManager.FilterExpensesByCategory(category);
        if (filteredExpenses.Any())
        {
            foreach (var expense in filteredExpenses)
            {
                Console.WriteLine($"{expense.Date.ToShortDateString()} | {expense.Name} | {expense.Amount:C} | {expense.Category}");
            }
        }
        else
        {
            Console.WriteLine($"No expenses found for category: {category}");
        }
    }
}
