﻿namespace InventoryManagement
{
    public class Product
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public int Stock { get; set; }

        // Constructor
        public Product(int id, string name, double price, int stock)
        {
            ID = id;
            Name = name;
            Price = price;
            Stock = stock;
        }

        // Object initializer constructor
        public Product() { }

        // Method to calculate the total value of stock
        public double CalculateTotalValue(params int[] quantities)
        {
            double totalValue = 0;

            foreach (var quantity in quantities)
            {
                totalValue += Price * quantity;
            }

            return totalValue;
        }

        // Local Function to validate stock
        public bool ValidateStock()
        {
            bool IsValid(int stock)
            {
                return stock >= 0;
            }

            return IsValid(Stock);
        }
    }
}
