using System;
using System.Collections.Generic;

namespace InventoryManagement
{
    public class Inventory
    {
        private List<Product> products = new List<Product>();

        // Property to access products list
        public List<Product> Products
        {
            get { return products; }
        }

        // Method to add a product to the inventory
        public void AddProduct(Product product)
        {
            products.Add(product);
        }

        // Method to display all products
        public void DisplayProducts()
        {
            foreach (var product in products)
            {
                Console.WriteLine($"ID: {product.ID}, Name: {product.Name}, Price: {product.Price}, Stock: {product.Stock}");
            }
        }

        // Method to calculate the total inventory value
        public double CalculateTotalInventoryValue()
        {
            double totalValue = 0;
            foreach (var product in products)
            {
                totalValue += product.CalculateTotalValue(product.Stock);
            }
            return totalValue;
        }
    }
}
