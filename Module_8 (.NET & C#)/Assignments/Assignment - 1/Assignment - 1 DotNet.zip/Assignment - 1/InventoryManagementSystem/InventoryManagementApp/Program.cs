﻿// using System;
// using InventoryManagement;

// namespace InventoryManagementApp
// {
//     class Program
//     {
//         static void Main(string[] args)
//         {
//             // Create an inventory instance
//             Inventory inventory = new Inventory();

//             // Add some products to the inventory
//             inventory.AddProduct(new Product(1, "Laptop", 1500, 10));
//             inventory.AddProduct(new Product(2, "Smartphone", 800, 25));
//             inventory.AddProduct(new Product(3, "Tablet", 600, 15));

//             // Display all products
//             Console.WriteLine("Products in Inventory:");
//             inventory.DisplayProducts();

//             // Calculate total value of inventory
//             double totalValue = inventory.CalculateTotalInventoryValue();
//             Console.WriteLine($"\nTotal value of inventory: ${totalValue}");

//             // Validate product stock
//             Console.WriteLine("\nValidating stock for each product:");
//             foreach (var product in inventory.Products)
//             {
//                 bool isValid = product.ValidateStock();
//                 Console.WriteLine($"{product.Name}: Stock is {(isValid ? "valid" : "invalid")}");
//             }
//         }
//     }
// }


using System;
using InventoryManagement;

namespace InventoryManagementApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create an inventory instance
            Inventory inventory = new Inventory();

            // Menu-driven loop
            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("Inventory Management System");
                Console.WriteLine("----------------------------");
                Console.WriteLine("1. Add Product");
                Console.WriteLine("2. Display Products");
                Console.WriteLine("3. Calculate Total Inventory Value");
                Console.WriteLine("4. Validate Stock for All Products");
                Console.WriteLine("5. Exit");
                Console.Write("Choose an option (1-5): ");
                
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddProduct(inventory);
                        break;
                    case "2":
                        DisplayProducts(inventory);
                        break;
                    case "3":
                        CalculateTotalValue(inventory);
                        break;
                    case "4":
                        ValidateStock(inventory);
                        break;
                    case "5":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

                // Pause the program to view results before the menu is displayed again
                if (!exit)
                {
                    Console.WriteLine("\nPress any key to return to the main menu...");
                    Console.ReadKey();
                }
            }

            Console.WriteLine("Exiting Inventory Management System. Goodbye!");
        }

        // Method to add a product to the inventory
        private static void AddProduct(Inventory inventory)
        {
            Console.WriteLine("\nAdd New Product");
            Console.Write("Enter Product ID: ");
            int id = int.Parse(Console.ReadLine());
            Console.Write("Enter Product Name: ");
            string name = Console.ReadLine();
            Console.Write("Enter Product Price: ");
            double price = double.Parse(Console.ReadLine());
            Console.Write("Enter Product Stock: ");
            int stock = int.Parse(Console.ReadLine());

            Product newProduct = new Product(id, name, price, stock);
            inventory.AddProduct(newProduct);

            Console.WriteLine("\nProduct added successfully.");
        }

        // Method to display all products
        private static void DisplayProducts(Inventory inventory)
        {
            Console.WriteLine("\nProducts in Inventory:");
            inventory.DisplayProducts();
        }

        // Method to calculate the total inventory value
        private static void CalculateTotalValue(Inventory inventory)
        {
            double totalValue = inventory.CalculateTotalInventoryValue();
            Console.WriteLine($"\nTotal value of inventory: ${totalValue}");
        }

        // Method to validate stock for all products
        private static void ValidateStock(Inventory inventory)
        {
            Console.WriteLine("\nValidating stock for each product:");
            foreach (var product in inventory.Products)
            {
                bool isValid = product.ValidateStock();
                Console.WriteLine($"{product.Name}: Stock is {(isValid ? "valid" : "invalid")}");
            }
        }
    }
}
