﻿namespace ExpenseTrackerLibrary
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class ExpenseManager
    {
        private List<Expense> expenses = new List<Expense>();

        // Add a new expense
        public void AddExpense(string name, decimal amount, string category, DateTime date)
        {
            var expense = new Expense(name, amount, category, date);
            expenses.Add(expense);
        }

        // List all expenses
        public List<Expense> ListAllExpenses()
        {
            return expenses;
        }

        // Calculate the total expenses
        public decimal GetTotalExpenses()
        {
            return expenses.Sum(e => e.Amount);
        }

        // Filter expenses by category
        public List<Expense> FilterExpensesByCategory(string category)
        {
            return expenses.Where(e => e.Category.Equals(category, StringComparison.OrdinalIgnoreCase)).ToList();
        }
    }
}
