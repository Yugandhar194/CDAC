﻿namespace LibraryManagement
{
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public bool IsBorrowed { get; private set; }

        // Constructor to initialize the book
        public Book(string title, string author)
        {
            Title = title;
            Author = author;
            IsBorrowed = false; // Initially the book is not borrowed
        }

        // Readonly property to check if the book is available for borrowing
        public bool IsAvailableForBorrowing
        {
            get
            {
                return !IsBorrowed; // If the book is not borrowed, it is available
            }
        }

        // Method to borrow the book
        public void BorrowBook()
        {
            if (IsAvailableForBorrowing)
            {
                IsBorrowed = true;
                Console.WriteLine($"You have borrowed '{Title}' by {Author}.");
            }
            else
            {
                Console.WriteLine($"'{Title}' by {Author} is currently unavailable for borrowing.");
            }
        }

        // Method to return the book
        public void ReturnBook()
        {
            if (!IsAvailableForBorrowing)
            {
                IsBorrowed = false;
                Console.WriteLine($"You have returned '{Title}' by {Author}.");
            }
            else
            {
                Console.WriteLine($"'{Title}' by {Author} was not borrowed.");
            }
        }
    }
}

