using System;
using System.Collections.Generic;

namespace LibraryManagement
{
    public class Library
    {
        private List<Book> books = new List<Book>();

        // Method to add a book to the library
        public void AddBook(Book book)
        {
            books.Add(book);
        }

        // Method to list all books in the library
        public void ListAllBooks()
        {
            Console.WriteLine("\nBooks in Library:");
            foreach (var book in books)
            {
                string status = book.IsAvailableForBorrowing ? "Available" : "Borrowed";
                Console.WriteLine($"Title: {book.Title}, Author: {book.Author}, Status: {status}");
            }
        }

        public Book GetBookByTitle(string title)
{
    foreach (var book in books)
    {
        if (book.Title.Equals(title, StringComparison.OrdinalIgnoreCase))
        {
            return book;
        }
    }
    return null; // Return null if no book matches the title
}

    }
}
