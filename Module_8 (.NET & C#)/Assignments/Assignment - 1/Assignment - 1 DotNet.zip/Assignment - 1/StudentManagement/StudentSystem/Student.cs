﻿namespace StudentSystem;

public class Student
{
        
        public string Name { get; set; }
        public int RollNumber { get; set; }
        public double Marks { get; set; }
        
        public string Grade
        {
            get
            {
                if (Marks >= 90) return "A";
                if (Marks >= 80) return "B";
                if (Marks >= 70) return "C";
                if (Marks >= 60) return "D";
                return "F";
            }
        }
}



