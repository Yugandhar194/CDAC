namespace StudentSystem
{
    public class StudentManager
    {
        List<Student> students{get;set;}

        public StudentManager()
        {
            students = new List<Student>();
        }
        
        public void AddStudent(Student student)
        {
            students.Add(student);
        }

        public void RemoveStudent(Student student)
        {
            students.Remove(student);
        }

        public List<Student> GetAllStudents()
        {
            return students;
        }

        public List<Student> GetStudentsByGrade(string grade)
        {
            return students.Where(s => s.Grade == grade).ToList();
        }

        public List<Student> GetStudentsByMarks(double marks)
        {
            return students.Where(s => s.Marks == marks).ToList();
        }

        public List<Student> GetStudentsByRollNumber(int rollNumber)
        {
            return students.Where(s => s.RollNumber == rollNumber).ToList();
        }

        public List<Student> GetStudentsByName(string name)
        {
            return students.Where(s => s.Name == name).ToList();
        }

        public List<Student> GetStudentsByGradeAndMarks(string grade, double marks)
        {
            return students.Where(s => s.Grade == grade && s.Marks == marks).ToList();
        }

        public List<Student> GetStudentsByGradeAndRollNumber(string grade, int rollNumber)
        {
            return students.Where(s => s.Grade == grade && s.RollNumber == rollNumber).ToList();
        }

        public List<Student> GetStudentsByGradeAndName(string grade, string name)
        {
            return students.Where(s => s.Grade == grade && s.Name == name).ToList();
        }

        public List<Student> GetStudentsByMarksAndRollNumber(double marks, int rollNumber)
        {
            return students.Where(s => s.Marks == marks && s.RollNumber == rollNumber).ToList();
        }

        public List<Student> GetStudentsByMarksAndName(double marks, string name)
        {
            return students.Where(s => s.Marks == marks && s.Name == name).ToList();
        }

        public List<Student> GetStudentsByRollNumberAndName(int rollNumber, string name)
        {
            return students.Where(s => s.RollNumber == rollNumber && s.Name == name).ToList();
        }

        public List<Student> GetStudentsByGradeAndMarksAndRollNumber(string grade, double marks, int rollNumber)
        {
            return students.Where(s => s.Grade == grade && s.Marks == marks && s.RollNumber == rollNumber).ToList();
        }

        public List<Student> GetStudentsByGradeAndMarksAndName(string grade, double marks, string name)
        {
            return students.Where(s => s.Grade == grade && s.Marks == marks && s.Name == name).ToList();
        }

        public List<Student> GetStudentsByGradeAndRollNumberAndName(string grade, int rollNumber, string name)
        {
            return students.Where(s => s.Grade == grade && s.RollNumber == rollNumber && s.Name == name).ToList();
        }

        public List<Student> GetStudentsByMarksAndRollNumberAndName(double marks, int rollNumber, string name)
        {
            return students.Where(s => s.Marks == marks && s.RollNumber == rollNumber && s.Name == name).ToList();
        }

        public List<Student> GetStudentsByGradeAndMarksAndRollNumberAndName(string grade, double marks, int rollNumber, string name)
        {
            return students.Where(s => s.Grade == grade && s.Marks == marks && s.RollNumber == rollNumber && s.Name == name).ToList();
        }

        public double GetAverageMarks()
        {
            return students.Average(s => s.Marks);
        }

        public double GetMaxMarks()
        {
            return students.Max(s => s.Marks);
        }

        public double GetMinMarks()
        {
            return students.Min(s => s.Marks);
        }

        public double GetTotalMarks()
        {
            return students.Sum(s => s.Marks);
        }

        
    }
}