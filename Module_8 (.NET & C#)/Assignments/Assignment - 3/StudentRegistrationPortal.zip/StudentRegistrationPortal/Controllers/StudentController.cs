﻿using Microsoft.AspNetCore.Mvc;
using StudentRegistrationPortal.Models;
using StudentRegistrationPortal.ViewModels;
using System.Collections.Generic;

namespace StudentRegistrationPortal.Controllers
{
    public class StudentController : Controller
    {
        private static List<Student> studentList = new();

        [HttpGet]
        public IActionResult Register()
        {
            var viewModel = new StudentViewModel
            {
                Student = new Student(),
                AvailableClasses = new List<string> { "Class 1", "Class 2", "Class 3", "Class 4" }
            };
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult Register(StudentViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                studentList.Add(viewModel.Student);
                return RedirectToAction("Index");
            }

            viewModel.AvailableClasses = new List<string> { "Class 1", "Class 2", "Class 3", "Class 4" };
            return View(viewModel);
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View(studentList);
        }
    }
}
