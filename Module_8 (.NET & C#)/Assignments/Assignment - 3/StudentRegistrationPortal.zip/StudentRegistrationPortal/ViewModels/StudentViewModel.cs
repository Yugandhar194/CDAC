﻿using System.Collections.Generic;
using StudentRegistrationPortal.Models;

namespace StudentRegistrationPortal.ViewModels
{
    public class StudentViewModel
    {
        public Student Student { get; set; }
        public List<string> AvailableClasses { get; set; }
    }
}
