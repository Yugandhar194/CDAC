﻿using System;
using System.ComponentModel.DataAnnotations;

namespace StudentRegistrationPortal.Models
{
    public class Student
    {
        [Required]
        public string Name { get; set; }

        [Range(5, 100, ErrorMessage = "Age must be between 5 and 100")]
        public int Age { get; set; }

        [Required]
        public string Class { get; set; }

        [EmailAddress]
        [Required]
        public string Email { get; set; }
    }
}
