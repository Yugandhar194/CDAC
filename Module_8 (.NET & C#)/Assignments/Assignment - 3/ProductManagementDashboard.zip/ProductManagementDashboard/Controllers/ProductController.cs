﻿using Microsoft.AspNetCore.Mvc;
using ProductManagementDashboard.Models;
using System.Collections.Generic;
using System.Linq;

namespace ProductManagementDashboard.Controllers
{
    public class ProductController : Controller
    {
        private static List<Product> products = new();

        [HttpGet]
        public IActionResult Index()
        {
            return View(products);
        }

        [HttpGet]
        public IActionResult AddOrEdit(int? id)
        {
            if (id == null) // Adding a new product
            {
                ViewBag.Heading = "Add New Product";
                return View(new Product());
            }

            // Editing an existing product
            var product = products.FirstOrDefault(p => p.ID == id);
            if (product == null)
                return NotFound();

            ViewBag.Heading = "Edit Product";
            return View(product);
        }

        [HttpPost]
        public IActionResult AddOrEdit(Product product)
        {
            if (ModelState.IsValid)
            {
                if (product.ID == 0) // Adding a new product
                {
                    product.ID = products.Count + 1;
                    products.Add(product);
                }
                else // Editing an existing product
                {
                    var existingProduct = products.FirstOrDefault(p => p.ID == product.ID);
                    if (existingProduct != null)
                    {
                        existingProduct.Name = product.Name;
                        existingProduct.Price = product.Price;
                        existingProduct.Stock = product.Stock;
                    }
                }
                return RedirectToAction("Index");
            }

            ViewBag.Heading = product.ID == 0 ? "Add New Product" : "Edit Product";
            return View(product);
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var product = products.FirstOrDefault(p => p.ID == id);
            if (product != null)
            {
                products.Remove(product);
            }
            return RedirectToAction("Index");
        }
    }
}
