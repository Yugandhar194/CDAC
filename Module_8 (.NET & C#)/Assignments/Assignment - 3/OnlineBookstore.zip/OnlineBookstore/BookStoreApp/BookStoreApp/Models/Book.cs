﻿using System.ComponentModel.DataAnnotations;

namespace BookStoreApp.Models
{
    public class Book
    {
        [Required]
        public string Title { get; set; }
        [Required]
        public string Author { get; set; }
        [Required]
        [Range (50.0,1000.0)]
        public float Price { get; set; }

        [DataType(DataType.Date)]
        public DateTime PublishedDate { get; set; }
        

    }
}
