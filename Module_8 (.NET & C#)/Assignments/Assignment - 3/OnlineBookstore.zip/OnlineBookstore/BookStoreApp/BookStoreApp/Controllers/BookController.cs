﻿using Microsoft.AspNetCore.Mvc;
using BookStoreApp.Models;

namespace BookStoreApp.Controllers
{
    public class BookController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }
        //POST: /Book/AddBook
    
        public IActionResult AddBook(Book book)
        {
            return View();
        }

        
        public IActionResult GetAllBooks() {
            return View();
        }

        [NonAction]
        public IActionResult Helper()
        {
            return View();
        }
    }
}
