﻿using Microsoft.AspNetCore.Mvc;
using UserAuthSystem.Models;
using System.Collections.Generic;

namespace UserAuthSystem.Controllers
{
    public class AccountController : Controller
    {
        private static List<User> registeredUsers = new();

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                registeredUsers.Add(user);
                TempData["Message"] = "Registration successful! Please log in.";
                return RedirectToAction("Login");
            }

            return View(user);
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginViewModel login)
        {
            if (ModelState.IsValid)
            {
                var user = registeredUsers.Find(u => u.Email == login.Email && u.Password == login.Password);
                if (user != null)
                {
                    TempData["Message"] = $"Welcome back, {user.Email}!";
                    return RedirectToAction("Dashboard");
                }

                ModelState.AddModelError(string.Empty, "Invalid email or password");
            }

            return View(login);
        }

        [HttpGet]
        public IActionResult Dashboard()
        {
            if (TempData["Message"] != null)
            {
                ViewBag.Message = TempData["Message"];
            }
            return View();
        }

        [HttpPost]
        public IActionResult Logout()
        {
            TempData["Message"] = "You have logged out successfully.";
            return RedirectToAction("Login");
        }
    }
}
