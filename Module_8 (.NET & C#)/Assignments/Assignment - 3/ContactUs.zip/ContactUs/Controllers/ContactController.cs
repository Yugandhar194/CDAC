﻿using Microsoft.AspNetCore.Mvc;
using ContactUsPage.Models;

namespace ContactUsPage.Controllers
{
    public class ContactController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(Contact contact)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Message = "Thank you for reaching out to us! We'll get back to you soon.";
                return View();
            }

            return View(contact);
        }
    }
}
