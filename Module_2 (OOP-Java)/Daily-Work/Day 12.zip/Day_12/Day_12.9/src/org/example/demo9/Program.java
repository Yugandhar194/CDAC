package org.example.demo9;
//Top Level class
public class Program {	//Program.class
	public static void main(String[] args) {
		//Local class
		class Complex{	//Program$1Complex.class
			
		}
	}
}
