package org.example.demo1;

//Top-level class
class Outer{	//Outer.class
	//Nested class
	class Inner{	//Outer$Inner.class
		
	}
}

public class Program {
	public static void main(String[] args) {
		
	}
}
