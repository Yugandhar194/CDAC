const fs = require('fs');

fs.writeFileSync("my-notes.txt", "This is text data");
fs.appendFile();

console.log("after writing file");