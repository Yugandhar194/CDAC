exports.sum = (a,b)=>{
    return a+b;
}

exports.square = (a)=>{
    return a*a;
}
// exports.property_name = value