const myModule = require('../my-modules/utility.js')

const x = myModule.sum(4,6);

myModule.square(4);