// import {sum,square} from './utility.js';
// import myData from './mymodule.js'

import { createServer } from "http";

// const x = sum(3,5);
// const s = square(6);

// console.log("sum is",x,"square is",s,"mydata",myData);

const server = createServer((request,response)=>{
    response.write("hi there");
    response.end();
});

server.listen(4700,()=>{
    console.log("server is listening on 4700")
});