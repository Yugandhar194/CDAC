var myData = [];
//operations or calculations
myData.push(10);
myData.push(20);
myData.push(30);

export default myData;
// if any module has to export a single property and that too after performing certain operations/calculations (not immediately at the time of declaration)
// for the above case, we have to use export default 

