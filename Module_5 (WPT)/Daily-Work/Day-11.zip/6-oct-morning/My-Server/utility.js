export function sum (a,b) {
    return a+b;
}

export function square (n) {
    return n*n;
}  

export const PI = 3.14;