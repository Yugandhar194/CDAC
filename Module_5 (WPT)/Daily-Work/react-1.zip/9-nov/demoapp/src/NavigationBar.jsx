export function NavigationBar() {
    return (
        <nav>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </nav>
    )
}


// import { Component } from "react";

// export class NavigationBar extends Component{
//     render(){
//         return(
//             <nav>
//                 <ul>
//                     <li><a href="#">Home</a></li>
//                     <li><a href="#">About</a></li>
//                     <li><a href="#">Contact</a></li>
//                 </ul>
//             </nav>
//         )
//     }
// }