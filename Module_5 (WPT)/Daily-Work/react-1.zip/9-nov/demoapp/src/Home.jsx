import { Header } from "./Header";

export function Home(){
    return (
        <div>
            <Header heading="Welcome to Home" text="Home text"></Header>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid voluptatibus odio distinctio inventore voluptate reprehenderit voluptatem nulla aliquam veritatis assumenda. Dolor ipsum quos consequuntur similique, aliquid quae nesciunt eveniet nobis.
            </p>
        </div>
    )
}