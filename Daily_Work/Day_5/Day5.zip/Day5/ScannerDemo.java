import java.util.Scanner;

class ScannerDemo{
public static void main(String arg[]){

	Scanner sc = new Scanner(System.in);
	/*sc.nextInt();
	  sc.nextFloat();
	sc.next();
	sc.nextLine();
	sc.nextLong();
	char c = sc.next().charAt(0);  // pls enter 1st value
	*/


	//String s1 = sc.nextLine();
	//System.out.println(s1);

	//String s = sc.next();// it will take only first word in input string, and ignores after space
//	System.out.println(s);
	
	//sc.next();

	char c = sc.next().charAt(5);
	System.out.println(c);
	
	


	

	


}







}